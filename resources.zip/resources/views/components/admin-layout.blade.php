<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="bg-gray-100">
    <div class="flex min-h-screen">
        <!-- Sidebar -->
        <aside class="w-64 bg-white p-4 shadow hidden sm:block">
            <div class="mb-6 border-b pb-4">
                <div class="font-bold">{{ Auth::user()->name }}</div>
                <div class="text-sm text-gray-600">{{ Auth::user()->email }}</div>
                <form method="POST" action="{{ route('logout') }}" class="mt-2">
                    @csrf
                    <button type="submit" class="text-red-500 hover:underline">Se déconnecter</button>
                </form>
            </div>

            <nav class="space-y-2">
                <button onclick="loadSection('accueil')" class="block w-full text-left hover:text-blue-600">Accueil</button>
                
                <!-- Menu déroulant Référentiel -->
                <div x-data="{ open: false }" class="space-y-1">
                    <button @click="open = !open" class="block w-full text-left font-semibold hover:text-blue-600">
                        Référentiel
                    </button>
                    <div x-show="open" class="pl-4 space-y-1">
                        <button onclick="loadSection('article')" class="block w-full text-left">Article</button>
                        <button onclick="loadSection('bureau')" class="block w-full text-left">Bureau</button>
                        <button onclick="loadSection('categorie-fournisseur')" class="block w-full text-left">Catégorie de fournisseur</button>
                        <button onclick="loadSection('division')" class="block w-full text-left">Division</button>
                        <button onclick="loadSection('fournisseur')" class="block w-full text-left">Fournisseur</button>
                        <button onclick="loadSection('categorie-article')" class="block w-full text-left">Catégorie d'article</button>
                        <button onclick="loadSection('categorie-consommable')" class="block w-full text-left">Catégorie de consommable</button>
                        <button onclick="loadSection('categorie-employer')" class="block w-full text-left">Catégorie d'employé</button>
                        <button onclick="loadSection('service')" class="block w-full text-left">Service</button>
                        <button onclick="loadSection('utilisateur')" class="block w-full text-left">Utilisateur</button>
                    </div>
                </div>

                <button onclick="loadSection('stock')" class="block w-full text-left hover:text-blue-600">Stock</button>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="flex-1 p-6">
            {{ $slot }}
        </main>
    </div>

    <script>
        function loadSection(section) {
            fetch(`/admin-sections/${section}`)
                .then(res => res.text())
                .then(html => {
                    document.getElementById('content-area').innerHTML = html;
                })
                .catch(() => {
                    document.getElementById('content-area').innerHTML = '<p class="text-red-500">Erreur de chargement</p>';
                });
        }
    </script>
</body>
</html>
