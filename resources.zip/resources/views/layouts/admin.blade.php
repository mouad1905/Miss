<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="bg-gray-100">
    <div class="flex min-h-screen">
        <!-- Sidebar -->
        <aside class="w-64 bg-white p-4 shadow hidden sm:block">
            <div class="mb-6 border-b pb-4">
                <div class="font-bold">{{ Auth::user()->name }}</div>
                <div class="text-sm text-gray-600">{{ Auth::user()->email }}</div>
            </div>

            <nav class="space-y-2">
                <button onclick="loadSection('accueil')" class="block w-full text-left hover:text-blue-600">Accueil</button>
                <button onclick="loadSection('referentiel')" class="block w-full text-left hover:text-blue-600">Référentiel</button>
                <button onclick="loadSection('stock')" class="block w-full text-left hover:text-blue-600">Stock</button>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="flex-1 p-6">
            {{ $slot }}
        </main>
    </div>
</body>
</html>
