<x-admin-layout>
    <div id="content-area" class="p-4">
        @include('admin.sections.accueil')
    </div>
</x-admin-layout>
