<h3 class="text-lg font-bold mb-2">Bienvenue dans le tableau de bord admin</h3>
<p>Ceci est le contenu de l'accueil.</p>
