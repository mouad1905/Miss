<div class="flex">
    <!-- Sidebar -->
    <aside class="w-64 h-screen bg-gray-100 p-6 shadow-lg">
        <nav class="space-y-4">
            <a href="#" class="block text-black hover:text-blue-600">Article</a>
            <a href="#" class="block text-black hover:text-blue-600">Bureau</a>
            <a href="#" class="block text-black hover:text-blue-600">Catégorie de fournisseur</a>
            <a href="#" class="block text-black hover:text-blue-600">Division</a>
            <a href="#" class="block text-black hover:text-blue-600">Fournisseur</a>
            <a href="#" class="block text-black hover:text-blue-600">Catégorie d'article</a>
            <a href="#" class="block text-black hover:text-blue-600">Catégorie de consommable</a>
            <a href="#" class="block text-black hover:text-blue-600">Catégorie d'employer</a>
            <a href="#" class="block text-black hover:text-blue-600">Service</a>
            <a href="#" class="block text-black hover:text-blue-600">Utilisateur</a>
        </nav>
    </aside>

    <!-- Contenu principal -->
    <main class="flex-1 p-6">
        <!-- Ton contenu principal ici -->
        <h1 class="text-xl font-bold">Bienvenue dans le tableau de bord</h1>
    </main>
</div>

