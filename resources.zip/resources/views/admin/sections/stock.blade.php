<h3 class="text-lg font-bold mb-2">Gestion du Stock</h3>
<p>Liste du stock, inventaire, affectations…</p>
