<h3 class="text-lg font-bold mb-2">Article</h3>
<p>Contenu de la section article.</p>
